<?php 
session_start();
include('../admin/config/dbconn.php');

if (isset($_POST['add_btn'])) {

    $payee = mysqli_real_escape_string($con,$_POST['payee']);
    $date = mysqli_real_escape_string($con,$_POST['date']);
    $expense = mysqli_real_escape_string($con,$_POST['expense']);


    $user_query = "INSERT INTO quick_draw_jan(payee, date, expenses)VALUES('$payee', '$date', '$expense') ";
    $user_query_run = mysqli_query($con, $user_query);
    if($user_query_run){
        $_SESSION['message'] = "Added Successfully!";
        header("Location: quick_draw.php");
        exit(0);

    }
    else{
        $_SESSION['message'] = "Something went wrong!";
        header("Location: quick_draw.php");
        exit(0);
    }

}else{
    header("Location: quick_draw.php");
    exit(0);
}

?>