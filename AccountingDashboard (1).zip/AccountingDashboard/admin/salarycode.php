<?php 
session_start();
include('../admin/config/dbconn.php');

if (isset($_POST['add_btn'])) {

    $employeeid = mysqli_real_escape_string($con,$_POST['employeeid']);
    $date = mysqli_real_escape_string($con,$_POST['date']);
    $expense = mysqli_real_escape_string($con,$_POST['expense']);


    $user_query = "INSERT INTO salary_wages_jan(employeeid, date, expenses)VALUES('$employeeid', '$date', '$expense') ";
    $user_query_run = mysqli_query($con, $user_query);
    if($user_query_run){
        $_SESSION['message'] = "Added Successfully!";
        header("Location: salary_wages.php");
        exit(0);

    }
    else{
        $_SESSION['message'] = "Something went wrong!";
        header("Location: salary_wages.php");
        exit(0);
    }

}else{
    header("Location: salary_wages.php");
    exit(0);
}

?>