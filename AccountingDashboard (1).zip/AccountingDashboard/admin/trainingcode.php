<?php 
session_start();
include('../admin/config/dbconn.php');

if (isset($_POST['add_btn'])) {

    $agenda = mysqli_real_escape_string($con,$_POST['agenda']);
    $date = mysqli_real_escape_string($con,$_POST['date']);
    $expense = mysqli_real_escape_string($con,$_POST['expense']);


    $user_query = "INSERT INTO training_and_conf_jan(agenda, date, expenses)VALUES('$agenda', '$date', '$expense') ";
    $user_query_run = mysqli_query($con, $user_query);
    if($user_query_run){
        $_SESSION['message'] = "Added Successfully!";
        header("Location: training_and_conference.php");
        exit(0);

    }
    else{
        $_SESSION['message'] = "Something went wrong!";
        header("Location: training_and_conference.php");
        exit(0);
    }

}else{
    header("Location: training_and_conference.php");
    exit(0);
}

?>