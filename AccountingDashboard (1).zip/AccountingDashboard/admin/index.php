<?php 
include('includes/header.php');
include('config/dbconn.php');

?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">FINANCE DEPARTMENT</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Travel and Transportation

                            <?php 
                                $dash_travel_query = "SELECT SUM(expenses) AS sum FROM travel_and_transpo_jan";
                                $dash_travel_query_run = mysqli_query($con, $dash_travel_query);

                                while($row = mysqli_fetch_assoc($dash_travel_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                            <img src="../admin/assets/img/worldwide.png" style="position:absolute; height: 80px; right:50px; top:20px">

                        </div>
                            
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="travel_and_transpo.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Training and Conference
                        <?php 
                                $dash_training_query = "SELECT SUM(expenses) AS sum FROM training_and_conf_jan";
                                $dash_training_query_run = mysqli_query($con, $dash_training_query);

                                while($row = mysqli_fetch_assoc($dash_training_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/workshop.png" style="position:absolute; height: 70px; right:50px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="training_and_conference.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">Office Supplies
                        <?php 
                                $dash_office_query = "SELECT SUM(expenses) AS sum FROM office_supplies_jan";
                                $dash_office_query_run = mysqli_query($con, $dash_office_query);

                                while($row = mysqli_fetch_assoc($dash_office_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/stationery.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="office_supplies.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-danger text-white mb-4">
                        <div class="card-body">Survey Instruments Materials & Photocopy
                        <?php 
                                $dash_survey_query = "SELECT SUM(expenses) AS sum FROM survey_instruments_jan";
                                $dash_survey_query_run = mysqli_query($con, $dash_survey_query);

                                while($row = mysqli_fetch_assoc($dash_survey_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/online-survey.png" style="position:absolute; height: 60px; right:40px; top:45px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="survey_instruments.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>


    <!-- second row -->


    <div class="container-fluid px-4">

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card text-bg-dark text-white mb-4">
                        <div class="card-body">Freight and Postages

                            <?php 
                                $dash_freight_query = "SELECT SUM(expenses) AS sum FROM freight_postages_jan";
                                $dash_freight_query_run = mysqli_query($con, $dash_freight_query);

                                while($row = mysqli_fetch_assoc($dash_freight_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/postcard.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                            
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="freight_postages.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color: brown;">
                        <div class="card-body">Telephone and Telegram
                        <?php 
                                $dash_telephone_query = "SELECT SUM(expenses) AS sum FROM telephone_telegram";
                                $dash_telephone_query_run = mysqli_query($con, $dash_telephone_query);

                                while($row = mysqli_fetch_assoc($dash_telephone_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/telephone.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="telephone_telegram.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:blueviolet;">
                        <div class="card-body">Salary and Wages
                        <?php 
                                $dash_office_query = "SELECT SUM(expenses) AS sum FROM salary_wages_jan";
                                $dash_office_query_run = mysqli_query($con, $dash_office_query);

                                while($row = mysqli_fetch_assoc($dash_office_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/salary.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="salary_wages.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#FF5900">
                        <div class="card-body">Employees Other Benefits
                        <?php 
                                $dash_benefit_query = "SELECT SUM(expenses) AS sum FROM employee_benefits_jan";
                                $dash_benefit_query_run = mysqli_query($con, $dash_benefit_query);

                                while($row = mysqli_fetch_assoc($dash_benefit_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/incentive.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="employee_benefit.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>


    <!-- third row -->


    <div class="container-fluid px-4">

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#A97B00;">
                        <div class="card-body">SSS Contribution

                            <?php 
                                $dash_sss_query = "SELECT SUM(expenses) AS sum FROM sss_contribution_jan";
                                $dash_sss_query_run = mysqli_query($con, $dash_sss_query);

                                while($row = mysqli_fetch_assoc($dash_sss_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/growth.png" style="position:absolute; height: 70px; right:60px; top:30px">



                        </div>
                            
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="sss_contribution.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color: #08506F;">
                        <div class="card-body">Philhealth Contribution
                        <?php 
                                $dash_philhealth_query = "SELECT SUM(expenses) AS sum FROM philhealth_contribution_jan";
                                $dash_philhealth_query_run = mysqli_query($con, $dash_philhealth_query);

                                while($row = mysqli_fetch_assoc($dash_philhealth_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/social-services.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="philhealth.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#6F6608;">
                        <div class="card-body">Pag-Ibig Loan and Contribution
                        <?php 
                                $dash_pagibig_query = "SELECT SUM(expenses) AS sum FROM pagibig_contribution_jan";
                                $dash_pagibig_query_run = mysqli_query($con, $dash_pagibig_query);

                                while($row = mysqli_fetch_assoc($dash_pagibig_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/benefits.png" style="position:absolute; height: 70px; right:50px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="pagibig_contri.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#0D00A9">
                        <div class="card-body">Insurance
                        <?php 
                                $dash_insurance_query = "SELECT SUM(expenses) AS sum FROM insurance_jan";
                                $dash_insurance_query_run = mysqli_query($con, $dash_insurance_query);

                                while($row = mysqli_fetch_assoc($dash_insurance_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/health-insurance.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="insurance.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>


    <!-- fourth row -->


    <div class="container-fluid px-4">

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#0A2756;">
                        <div class="card-body">Light and Water

                            <?php 
                                $dash_sss_query = "SELECT SUM(expenses) AS sum FROM light_water_jan";
                                $dash_sss_query_run = mysqli_query($con, $dash_sss_query);

                                while($row = mysqli_fetch_assoc($dash_sss_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/water-energy.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                            
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="light_water.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color: #3A0A56;">
                        <div class="card-body">Repairs and Maintenance
                        <?php 
                                $dash_repairs_query = "SELECT SUM(expenses) AS sum FROM repairs_maintenance_jan";
                                $dash_repairs_query_run = mysqli_query($con, $dash_repairs_query);

                                while($row = mysqli_fetch_assoc($dash_repairs_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/mechanic.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="repairs_maintenance.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#560A21;">
                        <div class="card-body">Registration and License
                        <?php 
                                $dash_license_query = "SELECT SUM(expenses) AS sum FROM registration_license_jan";
                                $dash_license_query_run = mysqli_query($con, $dash_license_query);

                                while($row = mysqli_fetch_assoc($dash_license_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/website.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="registration_license.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#560A0A">
                        <div class="card-body">Association Dues
                        <?php 
                                $dash_asso_query = "SELECT SUM(expenses) AS sum FROM association_dues_jan";
                                $dash_asso_query_run = mysqli_query($con, $dash_asso_query);

                                while($row = mysqli_fetch_assoc($dash_asso_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/network.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="asso_dues.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>


    <!-- fifth row -->


    <div class="container-fluid px-4">

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#4A8542;">
                        <div class="card-body">Membership Fees and Dues

                            <?php 
                                $dash_membership_query = "SELECT SUM(expenses) AS sum FROM membership_fees_jan";
                                $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                                while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/membership.png" style="position:absolute; height: 90px; right:60px; top:20px">


                        </div>
                            
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="membership_fee.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color: #BF9722;">
                        <div class="card-body">Professional Fees
                        <?php 
                                $dash_professional_query = "SELECT SUM(expenses) AS sum FROM professional_fees_jan";
                                $dash_professional_query_run = mysqli_query($con, $dash_professional_query);

                                while($row = mysqli_fetch_assoc($dash_professional_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/professionals.png" style="position:absolute; height: 80px; right:60px; top:20px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="professional_fees.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#BF4F22;">
                        <div class="card-body">Periodical and Library Materials
                        <?php 
                                $dash_library_query = "SELECT SUM(expenses) AS sum FROM library_materials_jan";
                                $dash_library_query_run = mysqli_query($con, $dash_library_query);

                                while($row = mysqli_fetch_assoc($dash_library_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>
                                <img src="../admin/assets/img/library.png" style="position:absolute; height: 70px; right:60px; top:30px">


                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="library_materials.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card text-white mb-4" style="background-color:#BF2222">
                        <div class="card-body">Miscellenous Expenses
                        <?php 
                                $dash_asso_query = "SELECT SUM(expenses) AS sum FROM misc_expenses_jan";
                                $dash_asso_query_run = mysqli_query($con, $dash_asso_query);

                                while($row = mysqli_fetch_assoc($dash_asso_query_run)){

                                    echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                                }
                            ?>

                                <img src="../admin/assets/img/trash.png" style="position:absolute; height: 70px; right:60px; top:30px">

                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="misc_expenses.php">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

     <!-- sixth row -->


     <div class="container-fluid px-4">

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#FFC300;">
            <div class="card-body">BIR Payments

                <?php 
                    $dash_membership_query = "SELECT SUM(expenses) AS sum FROM bir_payments_jan";
                    $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                    while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>

                    <img src="../admin/assets/img/revenue.png" style="position:absolute; height: 70px; right:60px; top:30px">


            </div>
                
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="bir_payments.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>


    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color: #000000;">
            <div class="card-body">Foods and Drinks
            <?php 
                    $dash_professional_query = "SELECT SUM(expenses) AS sum FROM foods_drinks_jan";
                    $dash_professional_query_run = mysqli_query($con, $dash_professional_query);

                    while($row = mysqli_fetch_assoc($dash_professional_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/iftar.png" style="position:absolute; height: 80px; right:60px; top:30px">


            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="foods_drinks.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
        
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#C70039;">
            <div class="card-body">Bank Service Fee
            <?php 
                    $dash_library_query = "SELECT SUM(expenses) AS sum FROM bank_service_jan";
                    $dash_library_query_run = mysqli_query($con, $dash_library_query);

                    while($row = mysqli_fetch_assoc($dash_library_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>

                    <img src="../admin/assets/img/bank.png" style="position:absolute; height: 70px; right:60px; top:30px">

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="bank_service.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#581845">
            <div class="card-body">Office Equipment
            <?php 
                    $dash_asso_query = "SELECT SUM(expenses) AS sum FROM office_equipment_jan";
                    $dash_asso_query_run = mysqli_query($con, $dash_asso_query);

                    while($row = mysqli_fetch_assoc($dash_asso_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>

                    <img src="../admin/assets/img/equipment.png" style="position:absolute; height: 70px; right:60px; top:30px">

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="office_equip.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>
</div>


 <!-- seventh row -->


 <div class="container-fluid px-4">

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#002982;">
            <div class="card-body">Medicines

                <?php 
                    $dash_membership_query = "SELECT SUM(expenses) AS sum FROM medicine_jan";
                    $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                    while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/medicine.png" style="position:absolute; height: 70px; right:60px; top:30px">
                

            </div>
                
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="medicine.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>


    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color: #640082;">
            <div class="card-body">Retirement Benefits
            <?php 
                    $dash_professional_query = "SELECT SUM(expenses) AS sum FROM retirement_benefits_jan";
                    $dash_professional_query_run = mysqli_query($con, $dash_professional_query);

                    while($row = mysqli_fetch_assoc($dash_professional_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/pension.png" style="position:absolute; height: 70px; right:60px; top:30px">


            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="retirement_benefits.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
        
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#0A8200;">
            <div class="card-body">Funeral Assistance
            <?php 
                    $dash_library_query = "SELECT SUM(expenses) AS sum FROM funeral_assist_jan";
                    $dash_library_query_run = mysqli_query($con, $dash_library_query);

                    while($row = mysqli_fetch_assoc($dash_library_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>

                    <img src="../admin/assets/img/funeral.png" style="position:absolute; height: 70px; right:60px; top:30px">

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="funeral_assist.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#B24400">
            <div class="card-body">Document Fee
            <?php 
                    $dash_asso_query = "SELECT SUM(expenses) AS sum FROM document_fee_jan";
                    $dash_asso_query_run = mysqli_query($con, $dash_asso_query);

                    while($row = mysqli_fetch_assoc($dash_asso_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/documentation.png" style="position:absolute; height: 70px; right:60px; top:30px">


            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="document_fee.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>
</div>



<!-- eighth row -->


<div class="container-fluid px-4">

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#0B9C61;">
            <div class="card-body">ISO Consultation

                <?php 
                    $dash_membership_query = "SELECT SUM(expenses) AS sum FROM iso_consultation_jan";
                    $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                    while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/brainstorming.png" style="position:absolute; height: 70px; right:80px; top:30px">
                

            </div>
                
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="iso_consultation.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>


    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color: #860B9C;">
            <div class="card-body">Common Areas
            <?php 
                    $dash_professional_query = "SELECT SUM(expenses) AS sum FROM common_areas_jan";
                    $dash_professional_query_run = mysqli_query($con, $dash_professional_query);

                    while($row = mysqli_fetch_assoc($dash_professional_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>

                    <img src="../admin/assets/img/area-chart.png" style="position:absolute; height: 80px; right:70px; top:20px">

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="common_areas.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
        
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#9C0B0B;">
            <div class="card-body">Quick to Draw
            <?php 
                    $dash_library_query = "SELECT SUM(expenses) AS sum FROM quick_draw_jan";
                    $dash_library_query_run = mysqli_query($con, $dash_library_query);

                    while($row = mysqli_fetch_assoc($dash_library_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/written-paper.png" style="position:absolute; height: 70px; right:60px; top:30px">

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="quick_draw.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#0B709C;">
            <div class="card-body">Wellness and Benefits
            <?php 
                    $dash_library_query = "SELECT SUM(expenses) AS sum FROM wellness_benefits_jan";
                    $dash_library_query_run = mysqli_query($con, $dash_library_query);

                    while($row = mysqli_fetch_assoc($dash_library_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/better-health.png" style="position:absolute; height: 90px; right:60px; top:20px">


            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="wellness.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div>
</div>
</div>


<!-- ninth row -->


<div class="container-fluid px-4">

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#4D24B3;">
            <div class="card-body">Honorarium of Officers

                <?php 
                    $dash_membership_query = "SELECT SUM(expenses) AS sum FROM honorarium_officers_jan";
                    $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                    while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/user.png" style="position:absolute; height: 70px; right:70px; top:30px">


            </div>
                
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="honorarium_officers.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>


    <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color: #797C32;">
            <div class="card-body">Incidental Expenses

            <?php 
                    $dash_membership_query = "SELECT SUM(expenses) AS sum FROM incidental_expenses_jan";
                    $dash_membership_query_run = mysqli_query($con, $dash_membership_query);

                    while($row = mysqli_fetch_assoc($dash_membership_query_run)){

                        echo '<h4 class="mb-0"> &#8369;' . number_format($row['sum'],2) . ' </h4>';

                    }
                ?>
                    <img src="../admin/assets/img/alarm.png" style="position:absolute; height: 70px; right:70px; top:30px">


            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="incidental_expenses.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
        
    </div>
    <!-- <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#9C0B0B;">
            <div class="card-body">Quick to Draw

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="quick_draw.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div> -->

    <!-- <div class="col-xl-3 col-md-6">
        <div class="card text-white mb-4" style="background-color:#0B709C;">
            <div class="card-body">Wellness and Benefits

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="wellness.php">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>

    </div> -->
</div>
</div>




<?php 
include('includes/footer.php');
include('includes/scripts.php');


?>