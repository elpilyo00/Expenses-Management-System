<?php 
session_start();
include('../admin/config/dbconn.php');

if (isset($_POST['add_btn'])) {

    $item = mysqli_real_escape_string($con,$_POST['item']);
    $date = mysqli_real_escape_string($con,$_POST['date']);
    $expense = mysqli_real_escape_string($con,$_POST['expense']);


    $user_query = "INSERT INTO survey_instruments_jan(item, date, expenses)VALUES('$item', '$date', '$expense') ";
    $user_query_run = mysqli_query($con, $user_query);
    if($user_query_run){
        $_SESSION['message'] = "Added Successfully!";
        header("Location: survey_instruments.php");
        exit(0);

    }
    else{
        $_SESSION['message'] = "Something went wrong!";
        header("Location: survey_instruments.php");
        exit(0);
    }

}else{
    header("Location: survey_instruments.php");
    exit(0);
}

?>