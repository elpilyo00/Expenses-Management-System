<?php 
session_start();
include('../admin/config/dbconn.php');

if (isset($_POST['add_btn'])) {

    $employeeid = mysqli_real_escape_string($con,$_POST['employeeid']);
    $benefit = mysqli_real_escape_string($con,$_POST['benefit']);
    $date = mysqli_real_escape_string($con,$_POST['date']);
    $expense = mysqli_real_escape_string($con,$_POST['expense']);


    $user_query = "INSERT INTO employee_benefits_jan(employeeid, benefit, date, expenses)VALUES('$employeeid', '$benefit', '$date', '$expense') ";
    $user_query_run = mysqli_query($con, $user_query);
    if($user_query_run){
        $_SESSION['message'] = "Added Successfully!";
        header("Location: employee_benefit.php");
        exit(0);

    }
    else{
        $_SESSION['message'] = "Something went wrong!";
        header("Location: employee_benefit.php");
        exit(0);
    }

}else{
    header("Location: employee_benefit.php");
    exit(0);
}

?>