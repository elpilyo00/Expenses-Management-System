<?php 
session_start();
include('includes/header.php');
include('config/dbconn.php');

?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">FOODS AND DRINKS</h1>
    </div>
<div class="py-5">
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">

            <?php include('message.php')?>

                <div class="card">
                    <div class="card-header">
                        <h4>Foods and Drinks</h4>
                    </div>
                    <div class="card-body">

                    <form action="foodscode.php" method="post">

                        <div class="form-group mb-3">
                            <label for="payee">Payee</label>
                            <input required type="text" class="form-control" id="payee" name="payee" placeholder="Enter Payee">
                        </div>

                         <div class="form-group mb-3">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date">
                        </div>

                        <div class="form-group mb-3">
                            <label for="expense">Expenses</label>
                            <input type="double" class="form-control" id="expense" name="expense" placeholder="Enter Expenses">
                        </div>

                        <div class="form-group mb-3 d-grid gap-2">
                            <button required type="submit" name="add_btn" class="btn btn-success">Add</button>
                        </div>

                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="container-fluid px-4">
<div class="row">

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4>Foods and Drink Data</h4>
        </div>
        <div class="card-body">


            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>PAYEE</th>
                        <th>DATE</th>
                        <th>EXPENSES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $query = "SELECT * FROM foods_drinks_jan";
                        $query_run = mysqli_query($con, $query);

                        if(mysqli_num_rows($query_run)){

                            foreach($query_run as $row){
                                ?>
                                     <tr>
                                        <td><?= $row['id']; ?></td>
                                        <td><?= $row['payee']; ?></td>
                                        <td><?= $row['date']; ?></td>
                                        <td><?= $row['expenses']; ?></td>
                                    </tr>
                                <?php
                            }

                        }else{
                            ?>
                                <tr>
                                    <td colspan = "4">No Record Found</td>
                                </tr>
                            <?php
                        }

                    ?>

                   
                </tbody>
            </table>

        </div>
    </div>
</div>

</div>
</div>



<?php 
include('includes/footer.php');
include('includes/scripts.php');


?>