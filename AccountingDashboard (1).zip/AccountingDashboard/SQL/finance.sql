-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2024 at 02:22 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finance`
--

-- --------------------------------------------------------

--
-- Table structure for table `association_dues_jan`
--

CREATE TABLE `association_dues_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bank_service_jan`
--

CREATE TABLE `bank_service_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bir_payments_jan`
--

CREATE TABLE `bir_payments_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bir_payments_jan`
--

INSERT INTO `bir_payments_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'IFO PACUCOA/003-295-960', '2023-01-09', 3447.18),
(2, 'LBP Katipunan branch FAO Bureau of Internal Revenue', '2023-01-09', 903.80);

-- --------------------------------------------------------

--
-- Table structure for table `common_areas_jan`
--

CREATE TABLE `common_areas_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `document_fee_jan`
--

CREATE TABLE `document_fee_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employee_benefits_jan`
--

CREATE TABLE `employee_benefits_jan` (
  `id` int(5) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `benefit` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `foods_drinks_jan`
--

CREATE TABLE `foods_drinks_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foods_drinks_jan`
--

INSERT INTO `foods_drinks_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-13', 31473.66);

-- --------------------------------------------------------

--
-- Table structure for table `freight_postages_jan`
--

CREATE TABLE `freight_postages_jan` (
  `id` int(5) NOT NULL,
  `pname` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `freight_postages_jan`
--

INSERT INTO `freight_postages_jan` (`id`, `pname`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-13', 5178.50);

-- --------------------------------------------------------

--
-- Table structure for table `funeral_assist_jan`
--

CREATE TABLE `funeral_assist_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `honorarium_officers_jan`
--

CREATE TABLE `honorarium_officers_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `honorarium_officers_jan`
--

INSERT INTO `honorarium_officers_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-07', 46348.00),
(2, 'Dr. Jocelyn Malang', '2023-01-07', 16951.00),
(3, 'Dr. Rosita Navarro', '2023-01-07', 79455.00),
(4, 'Dr. Adlai Castigador', '2023-01-31', 6562.00),
(5, 'Dr. Jocelyn Malang', '2023-01-31', 6562.00),
(6, 'Dr. Nenita Nagarit', '2023-01-31', 6562.00);

-- --------------------------------------------------------

--
-- Table structure for table `incidental_expenses_jan`
--

CREATE TABLE `incidental_expenses_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `incidental_expenses_jan`
--

INSERT INTO `incidental_expenses_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-28', 17249.00),
(2, 'Dr. Jocelyn Malang', '2023-01-28', 6914.00);

-- --------------------------------------------------------

--
-- Table structure for table `insurance_jan`
--

CREATE TABLE `insurance_jan` (
  `id` int(11) NOT NULL,
  `payee` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iso_consultation_jan`
--

CREATE TABLE `iso_consultation_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_materials_jan`
--

CREATE TABLE `library_materials_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `light_water_jan`
--

CREATE TABLE `light_water_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `light_water_jan`
--

INSERT INTO `light_water_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Meralco', '2023-01-12', 2476.30),
(4, 'Meralco', '2023-01-12', 7902.97);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `adminID` int(5) NOT NULL,
  `username` varchar(5) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `medicine_jan`
--

CREATE TABLE `medicine_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `membership_fees_jan`
--

CREATE TABLE `membership_fees_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `misc_expenses_jan`
--

CREATE TABLE `misc_expenses_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `misc_expenses_jan`
--

INSERT INTO `misc_expenses_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-13', 350.00),
(2, 'Dr. Adlai Castigador', '2023-01-13', 1818.65);

-- --------------------------------------------------------

--
-- Table structure for table `office_equipment_jan`
--

CREATE TABLE `office_equipment_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `office_equipment_jan`
--

INSERT INTO `office_equipment_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(3, 'Dr. Adlai Castigador', '2023-01-13', 5800.00);

-- --------------------------------------------------------

--
-- Table structure for table `office_supplies_jan`
--

CREATE TABLE `office_supplies_jan` (
  `id` int(11) NOT NULL,
  `item` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pagibig_contribution_jan`
--

CREATE TABLE `pagibig_contribution_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pagibig_contribution_jan`
--

INSERT INTO `pagibig_contribution_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Pag-Ibig Fund', '2023-02-07', 20405.08);

-- --------------------------------------------------------

--
-- Table structure for table `philhealth_contribution_jan`
--

CREATE TABLE `philhealth_contribution_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `professional_fees_jan`
--

CREATE TABLE `professional_fees_jan` (
  `id` int(11) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `quick_draw_jan`
--

CREATE TABLE `quick_draw_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registration_license_jan`
--

CREATE TABLE `registration_license_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `repairs_maintenance_jan`
--

CREATE TABLE `repairs_maintenance_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `retirement_benefits_jan`
--

CREATE TABLE `retirement_benefits_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `salary_wages_jan`
--

CREATE TABLE `salary_wages_jan` (
  `id` int(5) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salary_wages_jan`
--

INSERT INTO `salary_wages_jan` (`id`, `employeeid`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-09', 71127.00),
(2, 'Dr. Jocelyn Malang', '2023-01-09', 19500.00),
(3, 'Dr. Nenita Nagarit', '2023-01-09', 12728.00),
(4, 'Kristel Joy Noble', '2023-01-09', 6526.00),
(5, 'Lorena Pacubat', '2023-01-09', 4725.00),
(6, 'Heidy Santos', '2023-01-09', 5983.00),
(7, 'Ramon Pocholo Lapada', '2023-01-09', 8788.50);

-- --------------------------------------------------------

--
-- Table structure for table `sss_contribution_jan`
--

CREATE TABLE `sss_contribution_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `survey_instruments_jan`
--

CREATE TABLE `survey_instruments_jan` (
  `id` int(5) NOT NULL,
  `item` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `telephone_telegram`
--

CREATE TABLE `telephone_telegram` (
  `id` int(11) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `telephone_telegram`
--

INSERT INTO `telephone_telegram` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-13', 1348.00),
(2, 'Globe', '2023-01-12', 5504.93),
(3, 'PLDT', '2023-01-03', 261.44),
(4, 'PLDT', '2023-01-24', 261.44),
(5, 'PLDT', '2023-01-03', 3037.96),
(6, 'PLDT', '2023-01-24', 3037.96),
(7, 'PLDT', '2023-01-03', 7280.00),
(8, 'PLDT', '2023-01-24', 7280.00);

-- --------------------------------------------------------

--
-- Table structure for table `training_and_conf_jan`
--

CREATE TABLE `training_and_conf_jan` (
  `id` int(5) NOT NULL,
  `agenda` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `travel_and_transpo_jan`
--

CREATE TABLE `travel_and_transpo_jan` (
  `id` int(5) NOT NULL,
  `itenerary` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `travel_and_transpo_jan`
--

INSERT INTO `travel_and_transpo_jan` (`id`, `itenerary`, `date`, `expenses`) VALUES
(1, 'Dr. Adlai Castigador', '2023-01-13', 2309.29);

-- --------------------------------------------------------

--
-- Table structure for table `wellness_benefits_jan`
--

CREATE TABLE `wellness_benefits_jan` (
  `id` int(5) NOT NULL,
  `payee` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `expenses` double(65,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wellness_benefits_jan`
--

INSERT INTO `wellness_benefits_jan` (`id`, `payee`, `date`, `expenses`) VALUES
(1, 'Dr. Jaime Buzar', '2024-01-31', 10000.00),
(2, 'Dr. Maria Luz Macasinag', '2024-01-25', 10000.00),
(3, 'Dr. Rosita Navarro', '2023-01-11', 10000.00),
(4, 'Dr. Adlai Castigador', '2023-01-07', 5000.00),
(5, 'Dr. Adlai Castigador', '2023-01-31', 5000.00),
(6, 'Dr. Jocelyn Malang', '2023-01-07', 3000.00),
(7, 'Dr. Jocelyn Malang', '2023-01-31', 3000.00),
(8, 'Dr. Nenita Nagarit', '2023-01-07', 3000.00),
(9, 'Dr. Nenita Nagarit', '2023-01-31', 3000.00),
(10, 'Mr. Oliver Mijares', '2023-01-31', 3000.00),
(11, 'Ms. Kristel Joy Noble', '0023-01-07', 3000.00),
(12, 'Ms. Kristel Joy Noble', '2023-01-31', 3000.00),
(13, 'Dr. Adlai Castigador', '2023-01-31', 2000.00),
(14, 'Mr. Oliver Mijares', '2023-01-31', 2000.00),
(15, 'Ms. Heidy Santos', '2023-01-31', 2000.00),
(16, 'Ms. Kristel Joy Noble', '2023-01-31', 2000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `association_dues_jan`
--
ALTER TABLE `association_dues_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_service_jan`
--
ALTER TABLE `bank_service_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bir_payments_jan`
--
ALTER TABLE `bir_payments_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `common_areas_jan`
--
ALTER TABLE `common_areas_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_fee_jan`
--
ALTER TABLE `document_fee_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_benefits_jan`
--
ALTER TABLE `employee_benefits_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foods_drinks_jan`
--
ALTER TABLE `foods_drinks_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `freight_postages_jan`
--
ALTER TABLE `freight_postages_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `funeral_assist_jan`
--
ALTER TABLE `funeral_assist_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `honorarium_officers_jan`
--
ALTER TABLE `honorarium_officers_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidental_expenses_jan`
--
ALTER TABLE `incidental_expenses_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insurance_jan`
--
ALTER TABLE `insurance_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iso_consultation_jan`
--
ALTER TABLE `iso_consultation_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `library_materials_jan`
--
ALTER TABLE `library_materials_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `light_water_jan`
--
ALTER TABLE `light_water_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `medicine_jan`
--
ALTER TABLE `medicine_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_fees_jan`
--
ALTER TABLE `membership_fees_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `misc_expenses_jan`
--
ALTER TABLE `misc_expenses_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `office_equipment_jan`
--
ALTER TABLE `office_equipment_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `office_supplies_jan`
--
ALTER TABLE `office_supplies_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagibig_contribution_jan`
--
ALTER TABLE `pagibig_contribution_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `philhealth_contribution_jan`
--
ALTER TABLE `philhealth_contribution_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professional_fees_jan`
--
ALTER TABLE `professional_fees_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quick_draw_jan`
--
ALTER TABLE `quick_draw_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration_license_jan`
--
ALTER TABLE `registration_license_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repairs_maintenance_jan`
--
ALTER TABLE `repairs_maintenance_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `retirement_benefits_jan`
--
ALTER TABLE `retirement_benefits_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary_wages_jan`
--
ALTER TABLE `salary_wages_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sss_contribution_jan`
--
ALTER TABLE `sss_contribution_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_instruments_jan`
--
ALTER TABLE `survey_instruments_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `telephone_telegram`
--
ALTER TABLE `telephone_telegram`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_and_conf_jan`
--
ALTER TABLE `training_and_conf_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `travel_and_transpo_jan`
--
ALTER TABLE `travel_and_transpo_jan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wellness_benefits_jan`
--
ALTER TABLE `wellness_benefits_jan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `association_dues_jan`
--
ALTER TABLE `association_dues_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank_service_jan`
--
ALTER TABLE `bank_service_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bir_payments_jan`
--
ALTER TABLE `bir_payments_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `common_areas_jan`
--
ALTER TABLE `common_areas_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `document_fee_jan`
--
ALTER TABLE `document_fee_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_benefits_jan`
--
ALTER TABLE `employee_benefits_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `foods_drinks_jan`
--
ALTER TABLE `foods_drinks_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `freight_postages_jan`
--
ALTER TABLE `freight_postages_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `funeral_assist_jan`
--
ALTER TABLE `funeral_assist_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `honorarium_officers_jan`
--
ALTER TABLE `honorarium_officers_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `incidental_expenses_jan`
--
ALTER TABLE `incidental_expenses_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `insurance_jan`
--
ALTER TABLE `insurance_jan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `iso_consultation_jan`
--
ALTER TABLE `iso_consultation_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library_materials_jan`
--
ALTER TABLE `library_materials_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `light_water_jan`
--
ALTER TABLE `light_water_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `adminID` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicine_jan`
--
ALTER TABLE `medicine_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `membership_fees_jan`
--
ALTER TABLE `membership_fees_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `misc_expenses_jan`
--
ALTER TABLE `misc_expenses_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `office_equipment_jan`
--
ALTER TABLE `office_equipment_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `office_supplies_jan`
--
ALTER TABLE `office_supplies_jan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pagibig_contribution_jan`
--
ALTER TABLE `pagibig_contribution_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `philhealth_contribution_jan`
--
ALTER TABLE `philhealth_contribution_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `professional_fees_jan`
--
ALTER TABLE `professional_fees_jan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `quick_draw_jan`
--
ALTER TABLE `quick_draw_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration_license_jan`
--
ALTER TABLE `registration_license_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `repairs_maintenance_jan`
--
ALTER TABLE `repairs_maintenance_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `retirement_benefits_jan`
--
ALTER TABLE `retirement_benefits_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `salary_wages_jan`
--
ALTER TABLE `salary_wages_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sss_contribution_jan`
--
ALTER TABLE `sss_contribution_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `survey_instruments_jan`
--
ALTER TABLE `survey_instruments_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `telephone_telegram`
--
ALTER TABLE `telephone_telegram`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `training_and_conf_jan`
--
ALTER TABLE `training_and_conf_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `travel_and_transpo_jan`
--
ALTER TABLE `travel_and_transpo_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wellness_benefits_jan`
--
ALTER TABLE `wellness_benefits_jan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
