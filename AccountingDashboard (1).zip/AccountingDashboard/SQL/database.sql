CREATE TABLE `finance`.`login` (`adminID` INT(5) NOT NULL AUTO_INCREMENT , `username` VARCHAR(5) NOT NULL , `password` VARCHAR(10) NOT NULL , PRIMARY KEY (`adminID`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`travel_and_transpo_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `itenerary` VARCHAR(50) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`training_and_conf_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `agenda` VARCHAR(1000) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`office_supplies_jan` (`id` INT NOT NULL AUTO_INCREMENT , `item` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`survey_instruments_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `item` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`telephone_telegram` (`id` INT NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`freight_postages_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `pname` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`salary_wages_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT, `employeeid` VARCHAR(20) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `finance`.`employee_benefits_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT, `employeeid` VARCHAR(20) NOT NULL , `benefit` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `finance`.`sss_contribution_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT, `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `finance`.`philhealth_contribution_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT, `payee` VARCHAR(150) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `finance`.`pagibig_contribution_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT, `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `finance`.`insurance_jan` (`id` INT NOT NULL AUTO_INCREMENT , `payee` VARCHAR(150) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`light_water_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(150) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`repairs_maintenance_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`registration_license_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`association_dues_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`membership_fees_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`professional_fees_jan` (`id` INT NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`library_materials_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`misc_expenses_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`bir_payments_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`foods_drinks_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`bank_service_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`office_equipment_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`medicine_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`retirement_benefits_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`funeral_assist_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`document_fee_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`iso_consultation_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`common_areas_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`quick_draw_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`wellness_benefits_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`honorarium_officers_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `finance`.`incidental_expenses_jan` (`id` INT(5) NOT NULL AUTO_INCREMENT , `payee` VARCHAR(250) NOT NULL , `date` DATE NOT NULL , `expenses` DOUBLE(65,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
