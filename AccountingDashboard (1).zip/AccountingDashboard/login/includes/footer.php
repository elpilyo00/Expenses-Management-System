<script src="js/jquery.min.js"></script>
<script src="js/bootstrap5.bundle.min.js"></script>
<script src="js/scripts.js"></script>


</body>
</html>